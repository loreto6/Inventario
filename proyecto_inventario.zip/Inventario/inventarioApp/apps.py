from django.apps import AppConfig


class InventarioappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inventarioApp'
