import re
from django import forms
from .models import Product

class ProductForm(forms.ModelForm):
    class Meta:
        model = Product
        fields = ['name', 'description', 'stock', 'price','image']
        widgets = {
            'name': forms.TextInput(attrs={
                'placeholder': 'Solo letras y espacios'
            }),
            'description': forms.Textarea(attrs={
                'placeholder': 'Describe el producto'
            }),
            'stock': forms.NumberInput(attrs={
                'placeholder': 'Cantidad en stock'
            }),
            'price': forms.NumberInput(attrs={
                'placeholder': 'Precio del producto'
            }),
        }

    def clean_name(self):
        name = self.cleaned_data.get('name')
        if not re.match("^[a-zA-Z\s]+$", name):
            raise forms.ValidationError("El nombre solo debe contener letras y espacios.")
        return name


        


    
