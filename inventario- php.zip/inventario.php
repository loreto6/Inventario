<?php
// Configuración de la conexión a la base de datos
$servername = "database-1.cle69nephkjb.us-east-1.rds.amazonaws.com";
$username = "admin";
$password = "Inacap.2024";
$dbname = "base_inventario";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar la conexión
if ($conn->connect_error) {
    die("Error de conexión: " . $conn->connect_error);
}

// Variables para mensajes de alerta
$message = '';
$message_type = '';

// Manejar operaciones CRUD
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['submit'])) {
        // Validar y limpiar datos del formulario
        $nombre = limpiarInput($_POST['nombre']);
        $descripcion = limpiarInput($_POST['descripcion']);
        $precio_unitario = $_POST['precio_unitario'];
        $cantidad = $_POST['cantidad'];
        $id = isset($_POST['id']) ? $_POST['id'] : '';

        // Operación de creación
        if ($_POST['accion'] == 'crear') {
            if (productoExistente($nombre, $conn)) {
                $message = "Error: El producto '$nombre' ya existe en el inventario.";
                $message_type = 'danger';
            } else {
                $sql = "INSERT INTO productos (nombre, descripcion, precio_unitario, cantidad) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssdi", $nombre, $descripcion, $precio_unitario, $cantidad);
                
                if ($stmt->execute()) {
                    $message = "Producto creado correctamente";
                    $message_type = 'success';
                } else {
                    $message = "Error al crear producto: " . $conn->error;
                    $message_type = 'danger';
                }
                
                $stmt->close();
            }
        }
        // Operación de actualización
        elseif ($_POST['accion'] == 'actualizar' && !empty($id)) {
            // Validar si el nombre editado no está en conflicto con otro producto
            $nombre_actual = obtenerCampoProducto($id, 'nombre', $conn);
            if ($nombre != $nombre_actual && productoExistente($nombre, $conn)) {
                $message = "Error: El producto '$nombre' ya existe en el inventario.";
                $message_type = 'danger';
            } else {
                $sql = "UPDATE productos SET nombre=?, descripcion=?, precio_unitario=?, cantidad=? WHERE id=?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ssdii", $nombre, $descripcion, $precio_unitario, $cantidad, $id);
                
                if ($stmt->execute()) {
                    $message = "Producto actualizado correctamente";
                    $message_type = 'success';
                } else {
                    $message = "Error al actualizar producto: " . $conn->error;
                    $message_type = 'danger';
                }
                
                $stmt->close();
            }
        }
    }
}

// Operación de eliminación
if (isset($_GET['eliminar'])) {
    $id = $_GET['eliminar'];
    
    $sql = "DELETE FROM productos WHERE id=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    
    if ($stmt->execute()) {
        $message = "Producto eliminado correctamente";
        $message_type = 'success';
    } else {
        $message = "Error al eliminar producto: " . $conn->error;
        $message_type = 'danger';
    }
    
    $stmt->close();
}

// Función para limpiar y validar el input
function limpiarInput($data) {
    global $conn;
    $data = trim($data);
    $data = mysqli_real_escape_string($conn, $data); // Escapar caracteres especiales
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Función para verificar si el producto ya existe
function productoExistente($nombre, $conn) {
    $nombre_lower = strtolower($nombre);
    $nombre_plural = rtrim($nombre, 's');
    $nombre_plural_lower = strtolower($nombre_plural);

    $sql = "SELECT COUNT(*) as total FROM productos WHERE LOWER(nombre) = ? OR LOWER(nombre) = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $nombre_lower, $nombre_plural_lower);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    $stmt->close();
    
    return $row['total'] > 0;
}

?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Productos</title>
    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" integrity="sha384-JcKb8q3iqJ61gNV9KGb8thSsNjpSL0n8PARn9HuZOnIxN0hoP+VmmDGMN5t9UJ0Z" crossorigin="anonymous">
    <style>
        body {
            background-color: #e0f7fa; /* Celeste agua */
        }
        .container {
            margin-top: 50px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center mb-4">AGREGAR PRODUCTO</h2>

        <!-- Mostrar mensajes de alerta -->
        <?php if ($message): ?>
            <div class="alert alert-<?php echo $message_type; ?> alert-dismissible fade show" role="alert">
                <?php echo $message; ?>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        <?php endif; ?>

        <!-- Formulario para crear y actualizar productos -->
        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="mb-4">
            <input type="hidden" name="accion" value="<?php echo isset($_GET['editar']) ? 'actualizar' : 'crear'; ?>">
            <?php if (isset($_GET['editar'])): ?>
                <input type="hidden" name="id" value="<?php echo $_GET['editar']; ?>">
            <?php endif; ?>
            <div class="form-group">
                <label>Nombre:</label>
                <input type="text" class="form-control" name="nombre" pattern="[A-Za-z][A-Za-z ]*" title="Debe comenzar con una letra (Solo permite letras y espacios)" required placeholder="Solo permite letras y espacios" value="<?php echo isset($_GET['editar']) ? obtenerCampoProducto($_GET['editar'], 'nombre', $conn) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Descripción:</label>
                <textarea class="form-control" name="descripcion" placeholder="Descripción del producto"><?php echo isset($_GET['editar']) ? obtenerCampoProducto($_GET['editar'], 'descripcion', $conn) : ''; ?></textarea>
            </div>
            <div class="form-group">
                <label>Precio Unitario:</label>
                <input type="number" step="0.01" class="form-control" name="precio_unitario" required placeholder="" value="<?php echo isset($_GET['editar']) ? obtenerCampoProducto($_GET['editar'], 'precio_unitario', $conn) : ''; ?>">
            </div>
            <div class="form-group">
                <label>Cantidad:</label>
                <input type="number" class="form-control" name="cantidad" required placeholder="" value="<?php echo isset($_GET['editar']) ? obtenerCampoProducto($_GET['editar'], 'cantidad', $conn) : ''; ?>">
            </div>
            <button type="submit" name="submit" class="btn btn-primary">Guardar Producto</button>
        </form>

        <!-- Mostrar el total de productos -->
        <?php
        // Calcular el total de todos los productos
        $sql_total = "SELECT SUM(precio_unitario * cantidad) AS total FROM productos";
        $result_total = $conn->query($sql_total);
        $total = $result_total->fetch_assoc()['total'];
        ?>
        <h2 class="text-center mb-4">INVENTARIO (Total: $ <?php echo $total; ?>)</h2>

        <!-- Tabla para mostrar los productos existentes -->
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nombre</th>
                        <th>Descripción</th>
                        <th>Precio Unitario ($)</th>
                        <th>Cantidad</th>
                        <th>Total ($)</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Obtener y mostrar productos
                    $sql = "SELECT id, nombre, descripcion, precio_unitario, cantidad FROM productos";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            $total_producto = $row['precio_unitario'] * $row['cantidad'];
                            echo "<tr>
                                    <td>{$row['nombre']}</td>
                                    <td>{$row['descripcion']}</td>
                                    <td>{$row['precio_unitario']}</td>
                                    <td>{$row['cantidad']}</td>
                                    <td>{$total_producto}</td>
                                    <td>
                                        <a href='?editar={$row['id']}' class='btn btn-sm btn-warning'>Editar</a>
                                        <a href='?eliminar={$row['id']}' class='btn btn-sm btn-danger' onclick=\"return confirm('¿Estás seguro de eliminar este producto?');\">Eliminar</a>
                                    </td>
                                </tr>";
                        }
                    } else {
                        echo "<tr><td colspan='6' class='text-center'>No hay productos registrados.</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Bootstrap JS y scripts necesarios -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@1.16.1/dist/umd/popper.min.js" integrity="sha384-4JTzZR8U4R5UjIVR0HDGjgkPror3mGiFwpJeTlph/J6Zm+TR1w34Oz6ym3N8Lhsu" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js" integrity="sha384-B4gt1jrGC7Jh4AgTPSdUtOBvfO8sh+Wy0W/qDxp6qlxJrzy0Z6EYDH5PaXHqHW+N" crossorigin="anonymous"></script>
</body>
</html>

<?php
// Función auxiliar para obtener un campo específico del producto
function obtenerCampoProducto($id, $campo, $conn) {
    $sql = "SELECT $campo FROM productos WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        return $row[$campo];
    } else {
        return '';
    }
    $stmt->close();
}
?>
